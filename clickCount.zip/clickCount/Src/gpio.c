#include "stm32f446xx.h"

#define GPIOAEN (1U<<0)
#define SYSCFGEN (1U<<14)

//EXTI0_IRQ -> PA0
void configIntPA0(){
	__disable_irq();

	//Habilitando PA0 como entrada
	RCC->AHB1ENR |= GPIOAEN;
	GPIOA->MODER &= ~((1U<<0)|(1U<<1));


	RCC->APB2ENR |= SYSCFGEN;
	SYSCFG->EXTICR[0] &= ~((1U<<0) | (1U<<1) | (1U<<2) | (1U<<3));
	EXTI->IMR |= (1U<<0);
	EXTI->RTSR |= (1U<<0);
	//Para borda de descida usar:
	//EXTI->FTSR |= (1U<<0);
	EXTI->PR = (1U<<0);
	NVIC_SetPriority(EXTI0_IRQn, 0);
	NVIC_EnableIRQ(EXTI0_IRQn);
	__enable_irq();
}
