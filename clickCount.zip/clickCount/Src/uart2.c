
#include <stdint.h>
#include <stdio.h>
#include "stm32f446xx.h"
#include <systick.h>
#define enableGPIOA (1U<<0)
#define USART2EN (1U<<17)
#define APB1CLK 16000000 //considerando o SYSTCLK sem prescaler
#define TE (1U<<3)
#define RE (1U<<2)
#define UE (1U<<13)
#define TXE (1U<<7)
#define RXNE (1U<<5)
#define BUFFER_SIZE 100

char uart2Buffer[BUFFER_SIZE]; // Buffer para armazenar a string lida
uint32_t uart2Pos = 0;         // Para armazenar o índice atual do buffer

//Usa PA2 e PA3
void uart2RxTxIni(uint32_t baudRate, uint32_t clkPerif)
{
	uint16_t uartDiv;
	RCC->AHB1ENR |= enableGPIOA;                //Habilitando o clock GPIOA
	GPIOA->MODER |= (1U<<5);                    //PA2 como F. Alternativa
	GPIOA->MODER &= ~(1U<<4);                   //PA2 como F. Alternativa
	GPIOA->AFR[0] |= (1U<<8)|(1U<<9)|(1U<<10);  //AF7
	GPIOA->AFR[0] &= ~(1U<<11);                 //AF7
	RCC->APB1ENR |= USART2EN;                   //Habilitando o clock da Usart
	GPIOA->MODER |= (1U<<7);                    //PA3 como F. Alternativa
	GPIOA->MODER &= ~(1U<<6);                   //PA3 como F. Alternativa
	GPIOA->AFR[0] |= (1U<<14)|(1U<<13)|(1U<<12);//AF7
	GPIOA->AFR[0] &= ~(1U<<15);                 //AF7
	//Cálculo do valor da uartDiv para impor o baud
	uartDiv = (clkPerif + (baudRate/2))/baudRate;
	USART2->BRR = uartDiv;
	USART2->CR1 |= TE;
	USART2->CR1 |= RE;
	USART2->CR1 |= UE;
}

void uart2Write(int ch)
{
	//Aguarda para o DATA register ficar vazio
	while(!(USART2->SR & TXE))
	{
		//Fica retido aqui enquanto for falso. DR não vazio
	}
	USART2->DR = (ch &0xFF);
}

char uart2Read(void)
{
	while(!(USART2->SR & RXNE))
	{
		// Aguarda até que os dados estejam prontos para serem lidos
		/*Fica retido aqui enquanto for falso
		Se o RXNE for zero, o resultado AND é falso, o complemento é 1.
		Logo, fica parado dentro do while (1). Quando o valor de RXNE for 1, os dados estão prontos para serem lidos. Logo, vai sair do laço e transmitir.
		0: Data is not received
		1: Received data is ready to be read
		*/
	}
	return (USART2->DR & 0xFF); // Retorna o caractere lido
}

char* uart2ReadString(void)
{
   char ch;
   uart2Pos = 0;
   ch = uart2Read();
   //Enquanto não for encontrado o caractere de nova linha e o buffer não estiver cheio
   while (ch != '\n' && uart2Pos < BUFFER_SIZE - 1)
   {
       uart2Buffer[uart2Pos++] = ch; // Adiciona o caractere ao buffer
       ch = uart2Read(); // Lê o próximo caractere
   }
   // Adiciona o terminador de string '\0' ao final da string
   uart2Buffer[uart2Pos] = '\0';
   // Retorna o ponteiro para a string lida
   return uart2Buffer;
}

int equals(char *str1, char *str2)
{
    char c1 = ' ', c2=' ';
    int cont=0, conte=0;
    while(c1!='\0' || c2!='\0'){
        c1 = *str1;
        c2 = *str2;

        if(c1==c2){
            conte++;
        }
        if(c1!='\0') str1++;
        if(c2!='\0') str2++;
        cont++;
    }

    if(conte == cont){
       return 1;
    } else{
        return 0;
    }
}


int __io_putchar (int ch)
{
	uart2Write(ch);
	return ch;
}


