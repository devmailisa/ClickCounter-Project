#include <stm32f446xx.h>
#include <stdint.h>
#include <stdio.h>
#include <gpio.h>
#include <uart2.h>
#define baudRate 115200
#define clkSys	16000000

int cont = 0;
int main(void)
{
	uart2RxTxIni(baudRate, clkSys);
	configIntPA0();

    while(1){

    }
}

void EXTI0_IRQHandler()
{
	if(EXTI->PR & (1U<<0))
	{
		EXTI->PR = (1U<<0);
		cont++;
		printf("\r\nBotao clicado pela %d vez", cont);
	}
}
