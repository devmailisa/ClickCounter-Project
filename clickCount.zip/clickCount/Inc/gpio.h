
#ifndef GPIO_H_
#define GPIO_H_

void configIntPA0();

#endif /* GPIO_H_ */
