/*
 * systick.h
 *
 *  Created on: Feb 14, 2026
 *      Author: Isabelle
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_

void delayUs(uint32_t delay);
void delayMs(uint32_t delay);

#endif /* SYSTICK_H_ */
